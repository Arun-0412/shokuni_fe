import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, NgForm } from '@angular/forms';
import { SaloonService } from '../../../../services/saloon/saloon.service';
import { Http, Response, Headers, RequestOptions, RequestMethod } from '@angular/http';

@Component({
  selector: 'app-add-saloons',
  templateUrl: './add-saloons.component.html',
  styleUrls: ['./add-saloons.component.css']
})
export class AddSaloonsComponent implements OnInit {

	private pageTitle:String = 'saloons';
	private subTitle:String = 'add saloons';
	private saloonForm:FormGroup;
	countries: any;

	constructor(private saloon:SaloonService, private http : Http) {}

	ngOnInit() {
		this.doGET();
		this.saloonForm = new FormGroup ({
			password: new FormControl (null, [Validators.required, Validators.maxLength (20)]),
			rePassword: new FormControl (null, [Validators.required, Validators.maxLength (20)]),
		})
	}

	/**
	* Method to send request to update password
	* 
	* @param NgForm form
	* 
	* @return void
	*/
	submitAddSaloon (form:NgForm):void {
		// show loader
		this.saloon.vars.displayLoader(true);

		// send request to change password
		this.saloon.createSaloon (form.value).subscribe ((res) => {
		  // show success
		  this.saloon.vars.showNotification(this.saloon.vars.convertObjectToString (res.data), res.message, 'success');
		  
		  // hide loader
		  this.saloon.vars.displayLoader(false);
		}, (err) => {
		  // hide loader
		  this.saloon.vars.displayLoader(false);
		  // show errors
		  this.saloon.vars.showNotification(this.saloon.vars.convertObjectToString (err.errors), err.message);
		})
	}

	doGET() {
		console.log("GET");
		let url = "http://103.250.84.165/shokuni/public/v2/countries/get";
		let search = new URLSearchParams();

		this.http.get(url).subscribe(res =>
		  this.countries=res.json().data
		); 
	}

}
