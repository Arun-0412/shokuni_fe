import { SecondsToMinuitsPipe } from './seconds-to-minuits.pipe';

describe('SecondsToMinuitsPipe', () => {
  it('create an instance', () => {
    const pipe = new SecondsToMinuitsPipe();
    expect(pipe).toBeTruthy();
  });
});
