export class Sidebar {
    icon: String;
    title: String;
    link:String;
    nested:boolean;
    divider:boolean;
    nestedLinks:Array<{title:String, link:String}>
  }